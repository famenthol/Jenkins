package org.codehaus.groovy.runtime;

import java.io.Serializable;

/**
 * Test payload in a prohibited package name.
 *
 * @author Kohsuke Kawaguchi
 */
public class Security218 implements Serializable {
}
